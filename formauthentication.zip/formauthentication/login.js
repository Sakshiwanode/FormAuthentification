document.getElementById("loginForm").addEventListener("submit", function(event) { 
    event.preventDefault(); 
    
    const employeeID = event.target.employeeID.value; 
    const employeeDetails = getEmployeeDetails(employeeID); 
    if (employeeDetails) { 
        showPopup(employeeDetails); 
    } else { 
        alert("Employee ID not found."); 
    } 
}); 
function getEmployeeDetails(employeeID) { 
    const jsonData = localStorage.getItem("employees"); 
    const employees = jsonData ? JSON.parse(jsonData) : []; 
    return employees.find(emp => emp.employeeID === employeeID); 
} 
function showPopup(employeeDetails) { 
    const detailsElement = document.getElementById("details"); 
    detailsElement.innerHTML = ` 
        <strong>Employee ID:</strong> ${employeeDetails.employeeID}<br> 
        <strong>First Name:</strong> ${employeeDetails.firstname}<br> 
        <strong>Last Name:</strong> ${employeeDetails.lastname}<br> 
        <strong>Mobile Number:</strong> ${employeeDetails.mobno}<br> 
        <strong>Date of Birth:</strong> ${employeeDetails.dob}<br> 
        <strong>Place:</strong> ${employeeDetails.place}<br> 
        <strong>Aadhar Number:</strong> ${employeeDetails.adharnumber}<br> 
        <strong>PAN Card:</strong> ${employeeDetails.pancard}<br> 
        <strong>Document:</strong> ${employeeDetails.document}<br> 
    `; 
    document.getElementById("popup").style.display = "block"; 
} 
function closePopup() { 
    document.getElementById("popup").style.display = "none"; 
} 

