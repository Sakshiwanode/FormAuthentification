
document.getElementById("employeeForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const form = event.target;
    const firstname = form.firstname.value;
    const lastname = form.lastname.value;
    const mobno = form.mobno.value;
    const dob = new Date(form.dob.value);
    const place = form.place.value;
    const adharnumber = form.adharnumber.value;
    const pancard = form.pancard.value;
    const document = form.document.files[0];

    const today = new Date();
    const age = today.getFullYear() - dob.getFullYear();
   // const m = today.getMonth() - dob.getMonth();

    // if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
    //     age--;
    // }

    if (age < 18) {
        alert("Employee must be older than 18 years.");
        return;
    }

    if (age > 60) {
        alert("Employee must be younger than 60 years.");
        return;
    }

    const employeeID = firstname.substring(0, 3) + place.substring(0, 3) + mobno.slice(-4);
    const employeeDetails = {
        firstname,
        lastname,
        mobno,
        dob: form.dob.value,
        place,
        adharnumber,
        pancard,
        document: document.name,
        employeeID
    };
    saveData(employeeDetails);
    showPopup(employeeDetails);
});

function saveData(employeeDetails) {
    const jsonData = localStorage.getItem("employees");
    const employees = jsonData ? JSON.parse(jsonData) : [];
    // console.log("data:"+employees.age);
    employees.push(employeeDetails);
    localStorage.setItem("employees", JSON.stringify(employees));
}

function showPopup(employeeDetails) {
    const detailsElement = document.getElementById("details");
    detailsElement.innerHTML = `
        <strong>Employee ID:</strong> ${employeeDetails.employeeID}<br>
        <strong>First Name:</strong> ${employeeDetails.firstname}<br>
        <strong>Last Name:</strong> ${employeeDetails.lastname}<br>
        <strong>Mobile Number:</strong> ${employeeDetails.mobno}<br>
        <strong>Date of Birth:</strong> ${employeeDetails.dob}<br>
        <strong>Place:</strong> ${employeeDetails.place}<br>
        <strong>Aadhar Number:</strong> ${employeeDetails.adharnumber}<br>
        <strong>PAN Card:</strong> ${employeeDetails.pancard}<br>
        <strong>Document:</strong> ${employeeDetails.document}<br>
    `;
    document.getElementById("popup").style.display = "block";
}

function closePopup() {
    document.getElementById("popup").style.display = "none";
}